/// <reference types="vite/client" />

interface ImportMetaEnv {
  readonly VITE_APP_NAME?: string;
  readonly VITE_API_BASE_URL?: string;
  readonly VITE_API_TIMEOUT_MS?: string;
  readonly VITE_USE_MOCK_API?: string;
  readonly VITE_DEFAULT_BANK_CODE?: string;
}

interface ImportMeta {
  readonly env: ImportMetaEnv;
}
