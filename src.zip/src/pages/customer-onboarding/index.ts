export { default } from './CustomerOnboardingPage';
