export { default } from './AssignPasswordPage';
