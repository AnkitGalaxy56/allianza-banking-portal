import StatusPage from './StatusPage';

export default function NotFoundPage() {
  return <StatusPage title="Page not found" message="The page you are looking for does not exist or has moved." />;
}
