export { default } from './DeviceResetPage';
