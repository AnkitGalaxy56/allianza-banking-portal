export { default } from './BankPage';
