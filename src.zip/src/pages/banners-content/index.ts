export { default } from './BannersPage';
