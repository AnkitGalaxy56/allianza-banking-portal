export { default } from './RequestModulePage';
