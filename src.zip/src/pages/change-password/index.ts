export { default } from './ChangePasswordPage';
