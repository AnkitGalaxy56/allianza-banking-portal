export { default } from './UploadImagesPage';
